import logging
import datetime
import sys


# --------------------------------------------------
# 初期処理用の共通クラス
# --------------------------------------------------
class InitRds:

	# --------------------------------------------------
	# リトライ付更新処理-共通化
	# --------------------------------------------------
	def insertCommon(query, params):
	    retryCount = 0
	    retryFlg = True
	    with CONNECT.cursor(pymysql.cursors.DictCursor) as cur:
	        while (retryFlg):
	            try:
	                cur.execute("SET SESSION time_zone = 'Asia/Tokyo';")
	                cur.execute(query % params)
	                retryFlg = False
	                logging.debug('登録に成功しました。')
	            except Exception as e:
	                retryCount = retryCount + 1
	                if retryCount < RETRY_MAX_COUNT:
	                    logging.warning('登録に失敗しました。リトライします。(リトライ回数:%d)' % retryCount)
	                    time.sleep(RETRY_INTERVAL / 1000)
	                else:
	                    logging.error('リトライ回数を超過しました。登録処理を終了します。: %s' % e)
	                    retryFlg = False

