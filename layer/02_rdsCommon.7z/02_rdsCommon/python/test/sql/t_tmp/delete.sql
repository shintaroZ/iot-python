truncate table TMP_TEMPERATURE;
