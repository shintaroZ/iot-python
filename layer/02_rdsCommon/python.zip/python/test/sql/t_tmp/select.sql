select * from TMP_TEMPERATURE
order by RECEIVED_DATETIME;
